

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Resume_Final
 */
@WebServlet(description = "Request and Response", urlPatterns = { "/Resume_Final" })
public class Resume_Final extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Resume_Final() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw = response.getWriter();
		pw.append("<html>");
		pw.append("<html>");
		pw.append("<head>");
		pw.append("<title>Resume</title>");
		pw.append("<style>");
		pw.append("#myProgress {position: relative;width: 100%;height: 30px;background-color: #ddd;}");
		pw.append("#myBar {position: absolute;width: 10%;height: 100%;background-color: #4CAF50;}");
		pw.append("#label {text-align: center;line-height: 30px;color: white;}");
		pw.append("</style>");
		pw.append("<style>");
		pw.append("#myProgress1 {position: relative;width: 100%; height: 30px;background-color: #ddd;}");
		pw.append("#myBar1 {position: absolute;width: 10%;height: 100%;background-color: #4CAF50;}");
		pw.append("#label1 {text-align: center;line-height: 30px;color: white;}");
		pw.append("</style>");
		pw.append("</head>");
		pw.append("<body>");
		pw.append("<div style= width:100%;margin: auto;border: 1px solid black; > " );
		pw.append("<h1 style=text-align:center>Resume</h1>");
		pw.append("<div> ");
		pw.append("<img src='http://s17.postimg.org/5deaa0u3z/user_icon_png_person_user_profile_icon_20.png' alt='Profile Picture' style='width:128px;height:145px; float: left; margin-left:40px;'> ");
		pw.append("<p><ul style='list-style:none; font-size:20; margin-left:65px;' ><li>Name : 				Suprita Puned</li>");
		pw.append("<li>Location : 			Boston, Massachusetts </li>");
		pw.append("<li>Current : 			Northeastern University | Information Systems </li>");
		pw.append("<li>Previous : 			TATA Consultancy Services </li> ");
		pw.append("<li>Linkedin Profile : <a href='https://www.linkedin.com/in/suprita-puned-74205b4a'>linkedin.com/in/suprita-puned</a></li></ul></p> ");
		pw.append("</div>");
		pw.append("<hr>");
		pw.append("<div >");
		pw.append("<h3 style='text-align:center;'>Summary</h3>");
		pw.append("<pre>");
		pw.append("<p style=' font-size:20;  text-align: center; margin-left:100px; '>");
		pw.append("<ul style='list-style:none;'><li>I am a graduate student at Northeastern University pursuing Masters of Science inInformation Systems .</li>");
		pw.append("<li>With over 2 years of industry experience in the field of Business Analysis and testing, I bring a unique</li>");
		pw.append("<li>combination of expertise in requirement gathering, Business Analysis, Data Analysis and reporting.</li>");
		pw.append("<li>My prior experience at TCS as Quality Assurance Analyst and business Analyst involvedworking with the</li>");
		pw.append("<li>client for gathering functional requirements and translating them totechnical specifications.</li> ");
		pw.append("<li>I have worked on creation of reports and monitoring of datacoming from various sources to make available</li>");
		pw.append("<li>for reporting. I am a highly motivated individual and a quick learner with effective leadership, analytical,</li>");
		pw.append("<li>communication and presentation skills.</li></ul> </p>");
		pw.append("</pre>");
		pw.append("</div>");
		pw.append("<hr>");
		pw.append("<div> ");
		pw.append("<h3 style='text-align:center;'>Locations Stayed</h3>");
		pw.append("<p style=margin-left:20px; >");
		pw.append("<ul style='list-style:none;'><li>	Belgaum , India	</li>");
		pw.append("<li>		Ahmedabad , India	</li>");
		pw.append("<li>		Bangalore , India	</li>");
		pw.append("<li>		Boston , US	</li></ul></p>");
		pw.append("</div> ");
		pw.append("<hr>");
		pw.append("<div>");
        pw.append("<h3 style='text-align:center;'>Experience</h3>");
		pw.append("<pre>");
		pw.append("<p style=' font-size:20;  text-align: justify; margin-left:20px; '>");
		pw.append("<ul><li style='list-style:none;'>Title : System Engineer</li>");
		pw.append("<li style='list-style:none;'>Location : Bangalore , India</li>");
		pw.append("<li style='list-style:none;'>Time Period : Dec 2013 to Dec 2015</li>");
		pw.append("<li style='list-style:none;'>Description :</li>");
		pw.append("<li>Elicited requirements from key stakeholders, customers and subject matter experts todraft the Business</li>");
		pw.append("<li>and Technical Requirements Document of the project</li>");
		pw.append("<li>Participated in Joint Application Design sessions in the project design phase andworked in a team which</li>");
		pw.append("<li style='list-style:none;'>followed Agile Methodology </li>"); 
		pw.append("<li>Implemented a new test procedure which resulted in a 20% improvement in the efficiency</li>");
		pw.append("<li>Participated in all phases of testing including QA, User Acceptance Testing, End toEnd testing and helped</li>");
		pw.append("<li style='list-style:none;'>drive the test plan </li></ul></p>");
		pw.append(" </pre> ");
		pw.append("</div> ");
		pw.append("<hr>");
		pw.append("<div>");
		pw.append("<h3 style='text-align:center;'>Education</h3>");
		pw.append("<pre>");
		pw.append("<p style=font-size:20 ;  text-align: justify; margin-left:20px; >");
		pw.append("<ul style='list-style:none;'><li >Northeastern University , Boston , MA Master of Science (MS) Information Systems 2016 to 2017 </li>");
		pw.append("<li>KLE College of Engineering and Technology, Belgaum Bachelor of Engineering (B.E) Electronics and Communication 2009 to 2013</li></ul></p>");
		pw.append("</pre> ");
		pw.append("</div> ");
		pw.append("<hr>");
		pw.append("<div> ");
		pw.append("<h3  style='text-align:center;'>Academic Project</h3> ");
		pw.append("<pre>");
		pw.append("<p style=font-size:20 ;  margin-left:20px; >");
		pw.append("<ul><li style='list-style:none;'> <b>Web Design and User experience, Northeastern University , July 2016 to Aug 2016</b></li>");
		pw.append("<li>Designed and Developed responsive web UI using HTML5, Bootstrap & CSS3</li>");
		pw.append("<li>Performed DOM manipulation using JavaScript & implemented jQuery plugins such as File Upload,</li>");
		pw.append("<li>Chart.js, image sliders and infinite scrolling</li>");
		pw.append("<li>Integrated popular social media widgets (Twitter, Instagram) and Google Maps API to customize </li>");
		pw.append("<li>location and map information</li></ul></p> ");
		pw.append("<p style=font-size:20;   text-align: justify; margin-left:20px; >");
		pw.append("<ul><li style='list-style:none;'> <b>Database Design and Management, Northeastern University ,  Jan 2016 - April 2016</b></li>");
		pw.append("<li>Performed dimensional data modeling using Toad Data Modeler for a school database</li>");
		pw.append("<li>Designed OLAP cubes on SSAS and then designed dashboards using Power BI to perform differentanalysis.</li>");
		pw.append("<li>Implemented the dimensional model on multiple databases, viz., MySQL, Oracle and SQL </li></ul></p> ");
		pw.append("<p style= font-size:20;  text-align: justify; margin-left:20px; >");
		pw.append("<ul><li style='list-style:none;'> <b>Online Banking System, Northeastern University , Jan 2016 - April 2016</b></li>");
		pw.append("<li>Developed an online banking application using JAVA Swing application</li>");
		pw.append("<li>Designed use case scenarios and user interaction diagrams</li>");
		pw.append("<li>Developed a GUI through which the user can login and communicate with the banking system </li></ul></p> ");
		pw.append("</pre>");
		pw.append("</div> ");
		pw.append("<hr>");
		pw.append("<div> ");
		pw.append("<h3 style='text-align:center;'>Interests</h3>");
		pw.append("<p style=font-size:20 ;  margin-left:20px; >");
		pw.append("<ul style='list-style:none;'><li>Data analytics , Travelling , Business Analytics, Project Management ,Organizing Events</li></ul></p>");
		pw.append("</div> ");
		pw.append("<hr>");
		pw.append("<div> ");
		pw.append("<h3 style='text-align:center;'>Favorite Places</h3>");
		pw.append("<p style=font-size:20 ;  margin-left:20px; >");
		pw.append("<ul style='list-style:none;'><li>Chicago ,Ahmedabad ,Surat , Goa  </li></ul></p>");
		pw.append("</div> ");
		pw.append("<hr>");
		pw.append("<div>");
		pw.append("<h3 style='text-align:center;'>Skills</h3>");
		pw.append("<p style=font-size:20 ;  margin-left:20px; >");
		pw.append("<h5 style=margin-left:18px;>jQuery</h5> ");
		pw.append("<div style=padding-left: 5px; margin-left:10px; margin-right: 10px;> ");
		pw.append("<div id=myProgress >");
		pw.append("<div id='myBar' style='width:0%' >");
		pw.append("<div id='label'></div>");
		pw.append("</div>");
		pw.append("</div>");
		pw.append("<div>");
		pw.append("<br>");
		pw.append("<button  onclick='move()'>Show</button>");
		pw.append("<script>function move() {var elem = document.getElementById('myBar'); var width = 10;var id = setInterval(frame, 10); function frame() { if (width >= 70) {clearInterval(id);} else {width++; elem.style.width = width + '%';document.getElementById('label').innerHTML = width * 1  + '%';}}}</script> ");
		pw.append("</p>");
		pw.append("</div>");
		pw.append("<div>");
		pw.append("<p style='font-size:20 ;  margin-left:20px; '>");
		pw.append("<h5 >Bootstrap</h5>");
		pw.append("<div>");
		pw.append("<div id='myProgress1' >");
		pw.append("<div id='myBar1' style='width:0%' >");
		pw.append("<div id='label1'></div>");
		pw.append("</div>");
		pw.append("</div>");
		pw.append("<div>");
		pw.append("<br>");
		pw.append("<button  onclick='move1()'>Show</button>");
		pw.append("<script> function move1() { var elem = document.getElementById('myBar1');var width = 10;var id = setInterval(frame, 10);function frame() {if (width >= 90) {clearInterval(id);} else {width++;elem.style.width = width + '%';document.getElementById('label1').innerHTML = width * 1  + '%';}}}</script>");
		pw.append("</p>");
		pw.append("</div>");
		pw.append("</div>");
		pw.append("</body>");
		pw.append("</html>");
	
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
